import java.util.ArrayList;
import java.util.Scanner;

public class Principal {

    private static Scanner entrada = new Scanner(System.in);

    private static ArrayList<Cliente> clientes =
        new ArrayList<Cliente>();

    private static ArrayList<Servico> servicos =
        new ArrayList<Servico>();

    private static ArrayList<Agendamento> agendamentos =
        new ArrayList<Agendamento>();

    public static void main(String[] args) {

        cadastrarServicosIniciais();

        int opcao = 0;

        while (opcao != 3) {
            System.out.println("\n=== BARBERTECH ===");
            System.out.println("1 - Área do Cliente");
            System.out.println("2 - Área do Barbeiro");
            System.out.println("3 - Sair");
            System.out.print("Escolha: ");

            opcao = entrada.nextInt();
            entrada.nextLine();

            if (opcao == 1) {
                menuCliente();
            } else if (opcao == 2) {
                menuBarbeiro();
            } else if (opcao == 3) {
                System.out.println("Sistema encerrado.");
            } else {
                System.out.println("Opção inválida.");
            }
        }
    }

    private static void cadastrarServicosIniciais() {
        servicos.add(new Servico("Corte de cabelo", 40.00, 40));
        servicos.add(new Servico("Barba", 25.00, 30));
        servicos.add(new Servico("Cabelo e barba", 60.00, 60));
    }

    private static void menuCliente() {

        int opcao = 0;

        while (opcao != 5) {
            System.out.println("\n=== ÁREA DO CLIENTE ===");
            System.out.println("1 - Cadastrar cliente");
            System.out.println("2 - Consultar serviços e preços");
            System.out.println("3 - Consultar horários disponíveis");
            System.out.println("4 - Realizar agendamento");
            System.out.println("5 - Voltar");
            System.out.print("Escolha: ");

            opcao = entrada.nextInt();
            entrada.nextLine();

            if (opcao == 1) {
                cadastrarCliente();
            } else if (opcao == 2) {
                listarServicos();
            } else if (opcao == 3) {
                consultarHorarios();
            } else if (opcao == 4) {
                realizarAgendamento();
            } else if (opcao != 5) {
                System.out.println("Opção inválida.");
            }
        }
    }

    private static void cadastrarCliente() {

        System.out.print("Nome: ");
        String nome = entrada.nextLine();

        System.out.print("Telefone: ");
        String telefone = entrada.nextLine();

        if (nome.trim().isEmpty() ||
            telefone.trim().isEmpty()) {
            System.out.println("Preencha todos os campos.");
            return;
        }

        Cliente cliente = new Cliente(nome, telefone);
        clientes.add(cliente);

        System.out.println("Cliente cadastrado com sucesso!");
    }

    private static void listarServicos() {

        System.out.println("\n=== SERVIÇOS ===");

        for (int i = 0; i < servicos.size(); i++) {
            System.out.println((i + 1) + " - " +
                               servicos.get(i));
        }
    }

    private static void consultarHorarios() {

        System.out.print("Informe a data (DD/MM/AAAA): ");
        String data = entrada.nextLine();

        String[] horarios = {
            "09:00", "10:00", "11:00",
            "13:00", "14:00", "15:00",
            "16:00", "17:00"
        };

        System.out.println("\nHorários para " + data + ":");

        for (int i = 0; i < horarios.length; i++) {

            if (horarioDisponivel(data, horarios[i])) {
                System.out.println(horarios[i] + " - Disponível");
            } else {
                System.out.println(horarios[i] + " - Ocupado");
            }
        }
    }

    private static boolean horarioDisponivel(
        String data, String horario) {

        for (int i = 0; i < agendamentos.size(); i++) {

            Agendamento agendamento = agendamentos.get(i);

            if (agendamento.getData().equals(data) &&
                agendamento.getHorario().equals(horario)) {
                return false;
            }
        }

        return true;
    }

    private static void realizarAgendamento() {

        if (clientes.size() == 0) {
            System.out.println("Cadastre um cliente primeiro.");
            return;
        }

        System.out.println("\n=== CLIENTES CADASTRADOS ===");

        for (int i = 0; i < clientes.size(); i++) {
            System.out.println((i + 1) + " - " +
                               clientes.get(i).getNome());
        }

        System.out.print("Escolha o cliente: ");
        int indiceCliente = entrada.nextInt();
        entrada.nextLine();

        if (indiceCliente < 1 ||
            indiceCliente > clientes.size()) {
            System.out.println("Cliente inválido.");
            return;
        }

        listarServicos();

        System.out.print("Escolha o serviço: ");
        int indiceServico = entrada.nextInt();
        entrada.nextLine();

        if (indiceServico < 1 ||
            indiceServico > servicos.size()) {
            System.out.println("Serviço inválido.");
            return;
        }

        System.out.print("Data (DD/MM/AAAA): ");
        String data = entrada.nextLine();

        System.out.print("Horário (ex.: 09:00): ");
        String horario = entrada.nextLine();

        if (!horarioDisponivel(data, horario)) {
            System.out.println("Este horário já está ocupado.");
            return;
        }

        Cliente cliente = clientes.get(indiceCliente - 1);
        Servico servico = servicos.get(indiceServico - 1);

        Agendamento novo = new Agendamento(
            cliente, servico, data, horario
        );

        agendamentos.add(novo);

        System.out.println("\nAgendamento confirmado!");
        System.out.println(novo);
    }

    private static void menuBarbeiro() {

        System.out.print("Login: ");
        String login = entrada.nextLine();

        System.out.print("Senha: ");
        String senha = entrada.nextLine();

        if (login.equals("barbeiro") &&
            senha.equals("1234")) {

            System.out.println("\nAcesso autorizado.");

            System.out.println("\n=== AGENDA DE ATENDIMENTOS ===");

            if (agendamentos.size() == 0) {
                System.out.println("Nenhum agendamento realizado.");
            }

            for (int i = 0; i < agendamentos.size(); i++) {
                System.out.println(agendamentos.get(i));
            }

        } else {
            System.out.println("Login ou senha incorretos.");
        }
    }
}