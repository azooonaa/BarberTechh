# BarberTech – Sistema de Agendamento de Barbearia

Projeto desenvolvido em Java para gerenciamento simples de agendamentos de uma barbearia.

## Funcionalidades
- Cadastro de clientes (nome e telefone).
- Consulta de serviços, preços e duração.
- Consulta de horários disponíveis por data.
- Realização de agendamentos.
- Área do barbeiro com acesso à agenda.

## Estrutura do projeto
```text
BarberTech/
├── src/
│   ├── Agendamento.java
│   ├── Cliente.java
│   ├── Principal.java
│   └── Servico.java
├── .gitignore
└── README.md
```

## Requisitos
- Java JDK 8 ou superior.

## Como executar
Abra um terminal na pasta `BarberTech` e execute:

```bash
javac -d out src/*.java
java -cp out Principal
```

No Windows PowerShell, os mesmos comandos funcionam com um JDK instalado e configurado no PATH.

## Acesso de demonstração do barbeiro
- Login: `barbeiro`
- Senha: `1234`

> Observação: este é um projeto acadêmico de demonstração. O login está definido diretamente no código e não deve ser usado em produção.
